#ifndef __PWM_H
#define __PWM_H
#include "sys.h"



void PWM_Init(u16 arr,u16 psc);

#endif
